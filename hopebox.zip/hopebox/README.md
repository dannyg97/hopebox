# HopeBox
A mood tracker app that shows healthy alternatives to negative emotions. 

### What is HopeBox? 
HopeBox is an iOS app that focuses on the tracking and improvement of mental health. 


### Frontend 


### Backend 
We will pick **Firebase** as our backend container to support our frontend. 
https://firebase.google.com/

### Tools  
- IDE: Xcode 
- Languages: 
  - Swift for frontend 
  - Python for backend 
- Design: 
  - Sketch 
  - Adobe Illustrator  


### Learning Resources 
Start Developing iOS Apps(Swift)
https://developer.apple.com/library/archive/referencelibrary/GettingStarted/DevelopiOSAppsSwift/

### Developer 
@Danny 
@Ho
@Kaveh 
@Chengbin 

